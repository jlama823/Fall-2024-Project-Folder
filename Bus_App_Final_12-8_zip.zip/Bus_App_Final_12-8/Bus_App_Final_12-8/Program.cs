﻿using System;
using System.Collections.Generic;

// main class that instructs the user through the system options
// includes customer system and employee as well

public class MainClass
{
    public static void Main(string[] args)
    {
        Bookstore bookStore = new Bookstore();
        bool run = true;

        while (run)
        {
            Console.WriteLine("Welcome to the automated BookStore System!");
            Console.WriteLine("Select from one of the following options:");
            Console.WriteLine("\t1. Examine our selection");
            Console.WriteLine("\t2. Employee Interface");
            Console.WriteLine("\t3. Customer Interface");
            Console.WriteLine("\t4. Exit");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.WriteLine("Which type of product are you searching for today?");
                    Console.WriteLine("Please enter\n\t1 - for Books\n\t2 - for CDs\n\t3 - for DVDs");
                    int selection = int.Parse(Console.ReadLine());

                    List<Product> inventory = bookStore.GetInventory();
                    int count = 0;

                    if (selection == 1)
                    {
                        foreach (Product product in inventory)
                        {
                            if (product is Book)
                            {
                                count++;
                                Console.WriteLine(product);
                            }
                        }
                        Console.WriteLine("There are " + count + " different books currently available for purchase!");
                    }
                    else if (selection == 2)
                    {
                        foreach (Product product in inventory)
                        {
                            if (product is CD)
                            {
                                count++;
                                Console.WriteLine(product);
                            }
                        }
                        Console.WriteLine("There are " + count + " different CDs currently available for purchase!");
                    }
                    else if (selection == 3)
                    {
                        foreach (Product product in inventory)
                        {
                            if (product is DVD)
                            {
                                count++;
                                Console.WriteLine(product);
                            }
                        }
                        Console.WriteLine("There are " + count + " different DVDs currently available for purchase!");
                    }
                    break;
                case 2:
                    EmployeeInterface(bookStore);
                    break;
                case 3:
                    CustomerInterface(bookStore);
                    break;
                case 4:
                    run = false;
                    break;
                default:
                    Console.WriteLine("Invalid input, try again.");
                    break;
            }
        }
    }

    public static void EmployeeInterface(Bookstore bookStore)
    {
        bool manage = true;
        while (manage)
        {
            Console.WriteLine("Employee Management System:");
            Console.WriteLine("\t1. Add Product\n\t2. Remove Product\n\t3. View Inventory\n\t4. Exit to Main Menu");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    bookStore.AddProduct();
                    break;
                case 2:
                    bookStore.RemoveProduct();
                    break;
                case 3:
                    bookStore.DisplayInventory();
                    break;
                case 4:
                    manage = false;
                    break;
                default:
                    Console.WriteLine("Invalid choice, try again.");
                    break;
            }
        }
    }

    private static void CustomerInterface(Bookstore bookStore)
    {
        Console.WriteLine("Customer Interface:");
        Console.WriteLine("Which type of product are you searching for today?");
        Console.WriteLine("\t1. Books\n\t2. CDs\n\t3. DVDs");

        int selection = int.Parse(Console.ReadLine());
        bookStore.DisplayProductsByType(selection);
    }
}

// the class for DVD's

public class DVD : Product
{
    public DVD(double price, string name, int inStock) : base(price, name, inStock) { }

    public override string ToString()
    {
        return "DVD: " + GetName() + " - $" + GetPrice();
    }
}

// the class for CD's

public class CD : Product
{
    private string artist;

    public CD(string artist, double price, string name, int inStock) : base(price, name, inStock)
    {
        this.artist = artist;
    }

    public string GetArtist()
    {
        return artist;
    }

    public void SetArtist(string artist)
    {
        this.artist = artist;
    }

    public override string ToString()
    {
        return "CD: " + GetName() + " by " + artist + " - $" + GetPrice();
    }
}

// the class for the bookstore's inventory
// allows for employee removal of products from inventory

public class Bookstore
{
    private List<Product> inventory = new List<Product>();

    public Bookstore()
    {
        GenerateInventory();
    }

    private void GenerateInventory()
    {
        Book book1 = new Book("Harper Lee", 9.99, "To Kill A Mockingbird", 5);
        Book book2 = new Book("E.B. White", 7.99, "Charlotte's Web", 7);
        Book book3 = new Book("Jeff Kinney", 9.99, "Dairy of a Wimpy Kid", 9);

        CD cd1 = new CD("Lizzo", 7.99, "Cuz I Love You", 5);
        CD cd2 = new CD("Drake", 12.99, "What a Time to be Alive", 12);
        CD cd3 = new CD("Lil Uzi Vert", 15.99, "Eternal Atake", 10);

        DVD dvd1 = new DVD(15.99, "How To Train Your Dragon", 3);
        DVD dvd2 = new DVD(16.99, "Interstellar", 6);

        inventory.Add(book1);
        inventory.Add(book2);
        inventory.Add(book3);

        inventory.Add(cd1);
        inventory.Add(cd2);
        inventory.Add(cd3);

        inventory.Add(dvd1);
        inventory.Add(dvd2);
    }

    public List<Product> GetInventory()
    {
        return inventory;
    }

    public void DisplayInventory()
    {
        foreach (Product product in inventory)
        {
            Console.WriteLine(product);
        }
    }

    public void DisplayProductsByType(int selection)
    {
        int count = 0;
        foreach (Product product in inventory)
        {
            if ((selection == 1 && product is Book) ||
                (selection == 2 && product is CD) ||
                (selection == 3 && product is DVD))
            {
                Console.WriteLine(product);
                count++;
            }
        }

        string type = selection switch
        {
            1 => "books",
            2 => "CDs",
            3 => "DVDs",
            _ => "items"
        };
        Console.WriteLine($"There are {count} different {type} currently available for purchase.");
    }

    public void AddProduct()
    {
        Console.WriteLine("Enter product type (1 - Book, 2 - CD, 3 - DVD): ");
        int type = int.Parse(Console.ReadLine());

        Console.WriteLine("Enter name/title: ");
        string name = Console.ReadLine();

        Console.WriteLine("Enter price: ");
        double price = double.Parse(Console.ReadLine());

        Console.WriteLine("Enter stock quantity: ");
        int stock = int.Parse(Console.ReadLine());

        Product newProduct;
        if (type == 1) // Book
        {
            Console.WriteLine("Enter author: ");
            string author = Console.ReadLine();
            newProduct = new Book(author, price, name, stock);
        }
        else if (type == 2) // CD
        {
            Console.WriteLine("Enter artist: ");
            string artist = Console.ReadLine();
            newProduct = new CD(artist, price, name, stock);
        }
        else if (type == 3) // DVD
        {
            newProduct = new DVD(price, name, stock);
        }
        else
        {
            Console.WriteLine("Invalid product type.");
            return;
        }

        inventory.Add(newProduct);
        Console.WriteLine($"{newProduct.GetType().Name} added to inventory.");
    }

    public void RemoveProduct()
    {
        Console.WriteLine("Enter the name/title of the product to remove:");
        string name = Console.ReadLine();

        Product productToRemove = inventory.Find(p => p.GetName().Equals(name, StringComparison.OrdinalIgnoreCase));
        if (productToRemove != null)
        {
            inventory.Remove(productToRemove);
            Console.WriteLine("Product removed from inventory.");
        }
        else
        {
            Console.WriteLine("Product not found.");
        }
    }
}

// the class for book's

public class Book : Product
{
    private string author;

    public Book(string author, double price, string name, int inStock)
        : base(price, name, inStock)
    {
        this.author = author;
    }

    public string GetAuthor() => author;
    public void SetAuthor(string author) => this.author = author;

    public override string ToString()
    {
        return $"Book: {name} by {author} - ${price}";
    }
}

// the class for product's

public class Product
{
    protected double price;
    protected string name;
    protected int inStock;

    public Product(double price, string name, int inStock)
    {
        this.price = price;
        this.name = name;
        this.inStock = inStock;
    }

    public double GetPrice() => price;
    public void SetPrice(double price) => this.price = price;

    public string GetName() => name;
    public void SetName(string name) => this.name = name;

    public int GetInStock() => inStock;
    public void SetInStock(int inStock) => this.inStock = inStock;

    public override string ToString()
    {
        return $"{name} - ${price}";
    }
}